import React, { Component} from 'react';
import PropTypes from 'prop-types';
import ChatBot from 'react-simple-chatbot';

import './chat.sass'

class Result extends React.Component {
  constructor(props){
    super(props);
  }
  componentWillMount() {
    const { steps } = this.props;
    const { q1, q2, q3, q4, q5, q6, q7, q8, q9, q10 } = steps;

    this.setState({ q1, q2, q3, q4, q5, q6, q7, q8, q9, q10 });
    // check if any question makes positive result
    let result = "No covid, you are healthy"
    if (q4 != "yes") {
      result = "COVID positive, take care"
    }
  }

  render(){
    const { q1, q2, q3, q4, q5, q6, q7, q8, q9, q10} = this.state;
    let result = "No covid, you are healthy"
    if (q4 != "yes") {
      result = "COVID positive, take care"
    }
    if (result.includes("COVID")) {
      return (
        <div style={{ width: '100%' }}>
          <h3>{result}</h3>
        </div>
      )
    }
    return (
      <div style={{ width: '100%' }}>
          <h3>{result}</h3>
        </div>
    )
  }
}

class Review extends Component {
  constructor(props) {
    super(props);
  }

  componentWillMount() {
    const { steps } = this.props;
    const { q1, q2, q3, q4, q5, q6, q7, q8, q9, q10 } = steps;

    this.setState({ q1, q2, q3, q4, q5, q6, q7, q8, q9, q10 });

  }

  render() {
    const { q1, q2, q3, q4, q5, q6, q7, q8, q9, q10} = this.state;
    return (
      <div style={{ width: '100%' }}>
        <h3>Summary</h3>
        <table>
          <tbody>
            <tr>
              <td>Question 1: </td>
              <td>{q1.value}</td>
            </tr>
            <tr>
              <td>Question 2: </td>
              <td>{q2.value}</td>
            </tr>
            <tr>
              <td>Question 3: </td>
              <td>{q3.value}</td>
            </tr>
            <tr>
              <td>Question 4: </td>
              <td>{q4.value}</td>
            </tr>
            <tr>
              <td>Question 5: </td>
              <td>{q5.value}</td>
            </tr>
            <tr>
              <td>Question 6: </td>
              <td>{q6.value}</td>
            </tr>
            <tr>
              <td>Question 7: </td>
              <td>{q7.value}</td>
            </tr>
            <tr>
              <td>Question 8: </td>
              <td>{q8.value}</td>
            </tr>
            <tr>
              <td>Question 9: </td>
              <td>{q9.value}</td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

Review.propTypes = {
  steps: PropTypes.object,
};

Review.defaultProps = {
  steps: undefined,
};

Result.propTypes = {
  steps: PropTypes.object,
};

Result.defaultProps = {
  steps: undefined,
};

class SimpleForm extends Component {
    constructor(props) {
        super()
        //IMPLEMENT OTHER JUNK HERE
        this.state = {
            data: null //This is what our data will eventually be loaded into
        };
    }
    componentDidMount() {
        this.loadData();
    }
    loadData() {
        const apiUrl = 'http://localhost:8000/questions';
        fetch(apiUrl)
          .then((response) => response.json())
          .then((data) => this.setState({data: data}));
    }
  render() {
    if (!this.state.data) {
        return <div>Chatbot loading data from server</div>
    }
    return (
      <ChatBot className='unique'
        bot-delay="500"
        headerTitle="COVID self-checker"
        steps={[
          {
            id: '1',
            message: `${this.state.data[0].question}`,
            trigger: 'q1',
          },
          {
            id: 'q1',
            options: [
              { value: 'no', label: 'I agree', trigger: '2' },
              { value: 'yes', label: 'I do not agree', trigger: '2' },
            ],
          },
          {
            id: '2',
            message: `${this.state.data[1].question}`,
            trigger: 'q2',
          },
          {
            id: 'q2',
            options: [
              { value: 'yes', label: 'Yes', trigger: '3' },
              { value: 'no', label: 'No', trigger: '3' }
            ],
          },
          {
            id: '3',
            message: `${this.state.data[2].question}`,
            trigger: 'q3',
          },
          {
            id: 'q3',
            options: [
              { value: 'myself', label: 'Myself', trigger: '4' },
              { value: 'someone', label: 'Someone else', trigger: '4' },
            ],
          },
          {
            id: '4',
            message: `${this.state.data[2].question}`,
            trigger: 'q4',
          },
          {
            id: 'q4',
            options: [
              { value: '10', label: '10-20', trigger: '5' },
              { value: '20', label: '20-30', trigger: '5' },
            ],
          },
          {
            id: '5',
            message: `${this.state.data[2].question}`,
            trigger: 'q5',
          },
          {
            id: 'q5',
            options: [
              { value: 'male', label: 'Male', trigger: '6' },
              { value: 'female', label: 'Female', trigger: '6' },
              { value: 'other', label: 'Other', trigger: '6' },
            ],
          },
          {
            id: '6',
            message: `${this.state.data[2].question}`,
            trigger: 'q6',
          },  
          {
            id: 'q6',
            options: [
              { value: 'yes', label: 'Yes', trigger: '7' },
              { value: 'no', label: 'No', trigger: '7' }
            ],
          },
          {
            id: '7',
            message: `${this.state.data[2].question}`,
            trigger: 'q7',
          },
          {
            id: 'q7',
            options: [
              { value: 'yes', label: 'Yes', trigger: '8' },
              { value: 'no', label: 'No', trigger: '8' }
            ],
          },
          {
            id: '8',
            message: `${this.state.data[2].question}`,
            trigger: 'q8',
          },
          {
            id: 'q8',
            options: [
              { value: 'yes', label: 'Yes', trigger: '9' },
              { value: 'no', label: 'No', trigger: '9' },
              { value: 'idc', label: 'I do not know', trigger: '9' },
            ],
          },
          {
            id: '9',
            message: `${this.state.data[2].question}`,
            trigger: 'q9',
          },
          {
            id: 'q9',
            options: [
              { value: 'yes', label: 'Yes', trigger: 'review' },
              { value: 'no', label: 'No', trigger: 'review' }
            ],
          },
          {
            id: 'review',
            component: <Review />,
            asMessage: true,
            trigger: 'end-message',
          },
          {
            id: 'end-message',
            component: <Result />,
            asMessage: true,
            end: true,
          },
        ]}
      />
    );
  }
}

export default SimpleForm;