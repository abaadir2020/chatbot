import React from 'react'
import './backdrop.sass'
const Backdrop = (props) => {
    return (
        <div onClick={props.toggle} className="backdrop">
            
        </div>
    )
}

export default Backdrop
