import React, {useState} from 'react'

import '../sass/Home.sass'
import Container from '../components/Container'
import Chat from '../components/Chat'
import Backdrop from '../components/Backdrop'


const Home = () => {
    const [showChat, setShowChat] = useState(false)

    function show(){
        setShowChat(prev => !prev)
        console.log(showChat)
    }

    return (
        <React.Fragment>
            {showChat && <Chat></Chat>}
            {showChat && <Backdrop toggle={show}></Backdrop>}
            <section className="home">
                <header className='header-blue'></header>
                <Container>
                    <div className="stats">
                        <div className="left">
                            <div className="card card-total">
                                <h3>Total confirmed</h3>
                                <h1>1162857</h1>
                                <p>image here</p>
                            </div>
                        </div>
                        <div className="right">
                            <div className="card">
                                <h3>New confirmed</h3>
                                <h1>1162857</h1>
                            </div>
                            <div className="card">
                                <h3>New death</h3>
                                <h1>1162857</h1>
                            </div>
                            <div className="card">
                                <h3>Total death</h3>
                                <h1>1162857</h1>
                            </div>
                            <div className="card">
                                <h3>Total recovered</h3>
                                <h1>1162857</h1>
                            </div>
                        </div>
                    </div>
                    <div className="info">
                        <div className="info-left">
                            <h2>What you need to know</h2>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Obcaecati ab, a eius sapiente qui repellat!</p>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus quidem doloribus, saepe similique itaque recusandae, nesciunt vel culpa vitae iusto porro iste aut molestiae. Illum!</p>
                            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nisi debitis esse nemo cum tempora, cumque facilis libero.</p>
                        </div>
                        <div className="info-right">
                            <h2>Symptoms</h2>
                            <ul>
                                <li>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                </li>
                                <li>
                                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
                                </li>
                                <li>
                                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</p>
                                </li>
                                <li>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                </li>
                                <li>
                                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <button className='check' onClick={show}>Self-checker</button>

                </Container>
            </section>
        </React.Fragment>
    )
}

export default Home
