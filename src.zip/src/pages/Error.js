import React from 'react'

import '../sass/Home.sass'
import Container from '../components/Container'

const Home = () => {
    return (
        <React.Fragment>
            <section>
                <Container>
                    <h1>
                        Page not found
                    </h1>
                </Container>
            </section>
        </React.Fragment>
    )
}

export default Home
