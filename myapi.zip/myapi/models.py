from django.db import models


class Question(models.Model):
    question = models.TextField()
    possibleAnswers = models.CharField(max_length=60)

    def __str__(self):
        return self.question

# Create your models here.
